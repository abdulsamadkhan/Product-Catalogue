    SolarSwim
    
    Swimming costumes for all genders with solar cells to charge your devices while you sunbathe.
   
    Aimed at young adults
    
    Don't miss a beat while you're having fun in the sun! SolarSwim is the perfect choice for the tech-savvy, on-the-go millennial. Our innovative swimming costumes come with integrated solar cells that allow you to charge and access your devices while you're at the beach or pool. Enjoy your summer break with SolarSwim!